# W1L3: tentativo di separazione audio

Audio completo del video fornito, compresi menu, transizioni ed eventuali tentativi ripetuti. Non è ancora una traccia musicale montata in loop.

`music_background_trial.flac`: stima dello sfondo ricorrente, senza perdita di qualità di codifica. `preview_source_30s.wav`, `preview_music_30s.wav` e `preview_residual_30s.wav`: confronto allo stesso guadagno dei primi 30 secondi. `event_comparison_*_15s.wav`: confronto di un tratto con forte residuo.

Le coppie candidate_* confrontano sorgente e residuo per sei eventi. Non sono ancora effetti identificati o pronti per la ROM. La separazione può rimuovere strumenti musicali e lasciare effetti ripetuti. Nessuna qualità percettiva verificata. Timestamp relativi a questo video, senza l’offset del primo livello.

La ROM non usa questi file. La tua idea resta il criterio d’integrazione: musica attenuata negli effetti e suoni verificati attivati dalle azioni di gioco.
